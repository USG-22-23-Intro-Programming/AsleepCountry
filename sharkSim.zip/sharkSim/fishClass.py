from graphics import*
import random
 
class Fish:
 
    #Below shows the values to make a fish/image of the fish in the window we made!
 
    def __init__(self, pos, win, img, alive):
        self.x = pos[0]
        self.y = pos[1]
        self.win = win
        self.img = img
        self.img = Image(Point(self.x*20 + 110,self.y*20 + 60), img)
        self.img.draw(win)
        self.alive = alive
 
    def movement(self, x):
        #this movement is a random way of moveing for when the shark is not within the limit to catch it
        #for 1, it shows that I am moving right a cell and checking if it goes outside the grid as well
        if x == 1:
            self.x = self.x + 1
            deltaX = 1
            deltaY = 0
            if self.x>19:
                self.x = self.x - 1
                deltaX = 0
            self.img.move(20*deltaX, 20*deltaY)
        #2 shows I am moving left a cell and checking if it goes outside the grid
        if x == 2:
            self.x = self.x - 1
            deltaX = -1
            deltaY = 0
            if self.x<0:
                self.x = self.x + 1
                deltaX = 0
            self.img.move(20*deltaX, 20*deltaY)
        #for 3, it shows that I am moving up a cell and checking if it goes outside the grid
        if x == 3:
            self.y = self.y + 1
            deltaX = 0
            deltaY = 1
            if self.y>19:
                self.y = self.y - 1
                deltaY = 0
            self.img.move(20*deltaX, 20*deltaY)
        #Below shows that I am moving down a cell and checking if it goes outside the grid
        if x == 4:
            self.y = self.y - 1
            deltaX = 0
            deltaY = -1
            if self.y<0:
                self.y = self.y - 1
                deltaY = 0
            self.img.move(20*deltaX, 20*deltaY)
 
 
    def movement1(self, x):
        #this movement is for I am within the sharks 6 cells
        self.y = 0
        deltaY = 0
        deltaX = 0
        self.img.move(20*deltaX, 20*deltaY)
 
 
    def undraw(self):
        #this def. is for when the fish has the same positions as the shark meaning the shark ate the fish so I am
        #undrawing it so the image no longer exists in the window
        self.img.undraw()
        #self.alive = alive
           
