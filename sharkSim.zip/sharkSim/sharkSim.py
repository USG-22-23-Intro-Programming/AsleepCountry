from graphics import*
from shark import*
from fish import*
from Button import*
import time
#Above importing time so that the run button can work
import random
#Again adding another function which is random for the fish moving outside the area which is to get caught
 
def main():
 
    #Below are the buttons and the window itself to run the simulator
 
    win = GraphWin("Shark and menos", 600, 600)
    win.setBackground("thistle")
 
    Run = Button(win, Point(200, 510), Point(400, 565), "light blue", "Run")   
    Move = Button(win, Point(50, 500), Point(150, 575), "light blue", "Move")
    Quit = Button(win, Point(450, 500), Point(550, 575), "light blue", "Quit")
 
    #So here what we're doing is that we're making lines to form a grid. We're adding 100 to each time though throughout
    #the loops so that it is away from the edge of the window
    x = 50
    for i in range(21):
        Hori = Line(Point(100, x), Point(500, x))
        Hori.draw(win)
        x = x + 20
    x = 100
    for j in range(21):
        Vert = Line(Point(x, 50), Point(x, 450))
        Vert.draw(win)
        x = x + 20
    #After creating the grid, we are now creating 3 fish images to be in three different places
    #These will be passed through the class fish in the file "fish"
    x = random.randint(0, 19)
    y = random.randint(0, 19)
    Fish1 = Fish([x, y] , win, "Fish1.png", True)
    x = random.randint(0, 19)
    y = random.randint(0, 19)
    Fish2 = Fish([x, y], win, "Fish2.png", True)
    x = random.randint(0, 19)
    y = random.randint(0, 19)
    Fish3 = Fish([x, y], win, "Fish3.png", True)
    #Below shows that I am making an image of a shark by calling the class "Shark" which will make a shark image
    x = random.randint(0, 19)
    y = random.randint(0, 19)
    Shark1 = Shark([x, y], win, "Shark.png")
    hi = 1
  
 
 
    while True:
        m = win.getMouse()
    #the run button makes it so you dont have to click through it
        if Run.isClicked(m):
            while Fish1.alive == True and Fish2.alive == True and Fish3.alive == True:
                time.sleep(.5)
                x = random.randint(1, 4)
               Shark1.movement(x)
            #Below I am checking if the shark or the fish has the same position and if they did, the fish will undraw
                if Shark1.x == Fish1.x and Shark1.y == Fish1.y:
                    Fish1.undraw()
                else:
                    x = random.randint(1, 4)
                    Fish1.movement(x)
                if Shark1.x == Fish2.x and Shark1.y == Fish2.y:
                    Fish2.undraw()
                else:
                    x = random.randint(1, 4)
                    Fish2.movement(x)
                if Shark1.x == Fish3.x and Shark1.y == Fish3.y:
                    Fish3.undraw()
                else:
                    x = random.randint(1, 4)
                    Fish3.movement(x)
                if Quit.isClicked(m):
                    break
            else:
                T = Text(Point(300, 250), "Yay, all done!")
                T.draw(win)
                T.setSize(40)
    #the move button run throughs the window through each step and can see a fish dissappering if the shark catches it
        if Move.isClicked(m):
            x = random.randint(1, 4)
            Shark1.movement(x)
            #Below I am checking if the shark or the fish has the same position and if they did, the fish will undraw
            if Shark1.x == Fish1.x and Shark1.y == Fish1.y:
                Fish1.undraw()
            else:
                x = random.randint(1, 4)
                Fish1.movement(x)
            if Shark1.x == Fish2.x and Shark1.y == Fish2.y:
                Fish2.undraw()
            else:
                x = random.randint(1, 4)
                Fish2.movement(x)
            if Shark1.x == Fish3.x and Shark1.y == Fish3.y:
                Fish3.undraw()
            else:
                x = random.randint(1, 4)
                Fish3.movement(x)
        if Quit.isClicked(m):
            break
    win.close()
 
 
if __name__=="__main__":
    main()
