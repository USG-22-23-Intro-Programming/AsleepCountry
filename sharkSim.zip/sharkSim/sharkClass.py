from graphics import*
import random
 
class Shark:
 
    def __init__(self, pos, win, img):
        self.x = pos[0]
        self.y = pos[1]
        self.win = win
        self.img = img
        self.img = Image(Point(self.x*20 + 110,self.y*20 + 60), img)
        self.img.draw(win)
 
 
    def movement(self, x):
        #this movement is a random way of moveing for when the shark is not within the limit to catch it
        #for 1, it shows that I am moving right a cell and checking if it goes outside the grid as well
        if x == 1:
            self.x = self.x + 2
            deltaX = 2
            deltaY = 0
            if self.x>19:
                self.x = self.x - 2
                deltaX = -2
            self.img.move(20*deltaX, 20*deltaY)
        #2 shows I am moving left a cell and checking if it goes outside the grid
        if x == 2:
            self.x = self.x - 2
            deltaX = -2
            deltaY = 0
            if self.x<0:
                self.x = self.x + 2
                deltaX = 2
            self.img.move(20*deltaX, 20*deltaY)
        #for 3, it shows that I am moving up a cell and checking if it goes outside the grid
        if x == 3:
            self.y = self.y + 1
            deltaX = 0
            deltaY = 1
            self.x = self.x - 2
            deltaX = 2
            if self.x<0:
                self.x = self.x + 2
                deltaX = 2
            if self.y>19:
                self.y = self.y - 1
                deltaY = -1
            self.img.move(20*deltaX, 20*deltaY)
        #Below shows that I am moving down a cell and checking if it goes outside the grid
        if x == 4:
            self.y = self.y - 1
            deltaY = -1
            self.x = self.x + 2
            deltaX = 2
            if self.x>19:
                self.x = self.x - 2
                deltaX = -2
            if self.y<0:
                self.y = self.y - 1
                deltaY = -1
            self.img.move(20*deltaX, 20*deltaY)
 
